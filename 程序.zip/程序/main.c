/*
 * main.c - ADC0808 ʾ����/��ѹ��/������ģʽ��ʾ���������棩
 *
 * �㷴�������⣺
 * 1) ����ģʽ����� delay ���������°����޷��л�ģʽ��
 * 2) ÿ�仰���һ��������΢̫����
 *
 * �����޸ģ�
 * A) ɾ������ģʽ������ delay_us / delay_ms ������ʱ��
 *    - �� Timer1 ���� 1ms ϵͳ���ģ�tick��
 *    - ���ֲ��Ÿĳɡ�״̬�� + ��ʱ��������ѭ��������������ʱ�ɰ�����ģʽ
 * B) Timer0 �����ڷ���������������жϷ�ת BUZZER��
 * C) ��β���������̣��� 1200ms -> 1000ms����ĩͣ�ٴ� 120ms -> 90ms
 * D) ���� 11.0592MHz
 *
 * ˵����
 * - Timer0�����������
 * - Timer1��1ms tick��ȫ��ʱ���׼��
 */

#include "reg51.h"
#include "LCD12864.h"
#include "font.h"

/* font.c defines the asc2_1608 glyph array */
#include "font.c"

/* ===================================================================== */
/* ADC0808 and control lines                                             */
/* ===================================================================== */

#define ADC_VALUE P0

sbit START = P3^4;
sbit OE    = P3^6;
sbit EOC   = P3^5;
/* Long-press P3.2 then toggle P3.7 to switch between IN0 and IN1 */
sbit CH_SEL = P3^7;

#define COLLECT_NUM 64

/* Key and mode control */
sbit KEY = P3^2;
static uint8_t mode = 1;     /* 1=oscilloscope, 2=voltmeter, 3=music */
static uint8_t channel = 0;  /* 0=IN0, 1=IN1 */
/* ����״̬��0=���£�1=�ɿ� */
static uint8_t key_prev_state = 1;
/* ���°�����ʱ�����ms�� */
static unsigned long key_press_time_ms = 0;
/* ����Ƿ��Ѿ����������� */
static uint8_t long_press_handled = 0;

/* IN1 waveform selection */
static uint8_t wave_index = 0;
static uint8_t prev_range_code = 0;

sbit WAVE0 = P2^5;
sbit WAVE1 = P3^3;

sbit RANGE0 = P2^6;
sbit RANGE1 = P2^7;

/* Buzzer */
sbit BUZZER = P3^1;

/* �����ж���ֵ�����룩��������ʱ����Ϊ���� */
#define KEY_LONG_PRESS_MS 600UL

/* ===================================================================== */
/* Range and ADC conversion                                               */
/* ===================================================================== */

static uint8_t get_range_factor(void)
{
    uint8_t bits = (P2 >> 6) & 0x03;
    switch (bits) {
    case 0x00: return 1; /* 00: 1X */
    case 0x02: return 4; /* 10: 4X */
    case 0x01: return 2; /* 01: 2X */
    default:   return 1;
    }
}

void select_adc_channel(uint8_t ch)
{
    P1 = (P1 & 0xF8) | (ch & 0x07);
}

static uint16_t isqrt32ul(unsigned long x)
{
    unsigned long op = x;
    unsigned long res = 0;
    unsigned long one = 1UL << 30;
    while (one > op) one >>= 2;
    while (one != 0) {
        if (op >= res + one) {
            op -= res + one;
            res = res + 2 * one;
        }
        res >>= 1;
        one >>= 2;
    }
    return (uint16_t)res;
}

static int adc_to_mV(uint8_t adc_val, uint8_t ch)
{
    uint32_t v_adc_mV;
    long temp;
    v_adc_mV = (uint32_t)adc_val * 5000UL / 255UL;

    if (ch == 0) {
        uint8_t range = get_range_factor();
        temp = ((long)v_adc_mV - 2500L) * 2L;
        temp = temp / (long)range;
        return (int)temp;
    } else {
        return (int)v_adc_mV;
    }
}

static void set_waveform_pins(uint8_t wf)
{
    switch (wf & 0x03) {
    case 0: WAVE0 = 0; WAVE1 = 0; break;
    case 1: WAVE0 = 1; WAVE1 = 0; break;
    case 2: WAVE0 = 0; WAVE1 = 1; break;
    default: WAVE0 = 1; WAVE1 = 1; break;
    }
}

static void voltage_to_str(int v_mV, char *buf)
{
    char sign = '+';
    long val = v_mV;
    int integer, fractional, d1, d2;

    if (val < 0) { sign = '-'; val = -val; }
    integer = (int)(val / 1000);
    fractional = (int)(val % 1000);
    d1 = fractional / 100;
    d2 = (fractional % 100) / 10;

    buf[0] = sign;
    buf[1] = (char)((integer % 10) + '0');
    buf[2] = '.';
    buf[3] = (char)(d1 + '0');
    buf[4] = (char)(d2 + '0');
    buf[5] = '\0';
}

/* ===================================================================== */
/* LCD text helpers                                                      */
/* ===================================================================== */

static void LCD_ShowChar16x8(uint8_t page, uint8_t col, uint8_t ch)
{
    uint8_t j, i, list;
    list = col;
    if (ch < ' ' || ch > '~') return;
    ch = ch - ' ';
    for (j = 0; j < 8; j++) {
        for (i = 0; i < 2; i++) {
            write_one_list((uint8_t)(page + i), (uint8_t)(list + j),
                           asc2_1608[(uint8_t)ch][j * 2 + i]);
        }
    }
}

static void LCD_ShowStr16x8(uint8_t line, uint8_t col, uint8_t *str)
{
    uint8_t page, list;
    list = col;
    switch (line) {
    case 1: page = 0; break;
    case 2: page = 2; break;
    case 3: page = 4; break;
    case 4: page = 6; break;
    default: return;
    }
    while (*str) {
        if (*str < ' ' || *str > '~') { str++; continue; }
        if (list < 128) LCD_ShowChar16x8(page, list, *str);
        list += 8;
        if (list > 127) {
            page += 2;
            list = 0;
            if (page > 6) return;
        }
        str++;
    }
}

/* ===================================================================== */
/* ADC sample                                                            */
/* ===================================================================== */

uint8_t GatAdcValue()
{
    uint8_t temp;
    START = 1;
    START = 0;
    OE = 1;
    while (EOC == 0);
    temp = ADC_VALUE;
    OE = 0;
    return temp;
}

/* ===================================================================== */
/* System tick timer (Timer1) - 1ms tick                                 */
/* ===================================================================== */

#define FOSC_HZ 11059200UL
#define TIMER_TICK_HZ (FOSC_HZ/12UL) /* 921600 Hz */

/* 1ms ��Ҫ����Լ 921.6 -> 922 */
#define T1_COUNTS_1MS 922U
#define T1_RELOAD (65536U - T1_COUNTS_1MS) /* 65536-922=64614=0xFC66 */

static volatile unsigned long g_ms = 0;

void timer1_isr(void) interrupt 3
{
    TH1 = (unsigned char)(T1_RELOAD >> 8);  /* 0xFC */
    TL1 = (unsigned char)(T1_RELOAD & 0xFF);/* 0x66 */
    g_ms++;
}

static void systick_init(void)
{
    /* Timer1 Mode1 16-bit */
    TMOD = (TMOD & 0x0F) | 0x10;

    TH1 = (unsigned char)(T1_RELOAD >> 8);
    TL1 = (unsigned char)(T1_RELOAD & 0xFF);

    ET1 = 1;  /* enable Timer1 interrupt */
    EA  = 1;  /* global enable */
    TR1 = 1;  /* start Timer1 */
}

static unsigned long millis(void)
{
    unsigned long t;
    EA = 0;
    t = g_ms;
    EA = 1;
    return t;
}

/* ===================================================================== */
/* Buzzer output (Timer0) + Music state machine (NON-BLOCKING)           */
/* ===================================================================== */

/* ��������������freq *= 6/5  => half_period_us *= 5/6 */
#define PITCH_UP_NUM 5U
#define PITCH_UP_DEN 6U

static unsigned int pitch_half_period(unsigned int half_us)
{
    unsigned long t = (unsigned long)half_us * (unsigned long)PITCH_UP_NUM;
    t /= (unsigned long)PITCH_UP_DEN;
    if (t < 50UL) t = 50UL;
    return (unsigned int)t;
}

/* Timer0 reload for buzzer */
static volatile unsigned int t0_reload;
static volatile bit buzzer_running = 0;

void timer0_isr(void) interrupt 1
{
    unsigned int r = t0_reload;
    TH0 = (unsigned char)(r >> 8);
    TL0 = (unsigned char)(r & 0xFF);
    BUZZER = !BUZZER;
}

static void buzzer_set_half_period_us(unsigned int half_period_us)
{
    /* counts = half_us * TIMER_TICK_HZ / 1e6 */
    unsigned long counts_ul = (unsigned long)half_period_us * (unsigned long)TIMER_TICK_HZ;
    counts_ul /= 1000000UL;

    if (counts_ul < 1UL) counts_ul = 1UL;
    if (counts_ul > 60000UL) counts_ul = 60000UL;

    t0_reload = (unsigned int)(65536U - (unsigned int)counts_ul);
}

static void buzzer_start(void)
{
    /* Timer0 Mode1 16-bit */
    TMOD = (TMOD & 0xF0) | 0x01;
    TH0 = (unsigned char)(t0_reload >> 8);
    TL0 = (unsigned char)(t0_reload & 0xFF);
    ET0 = 1;
    EA  = 1;
    TR0 = 1;
    buzzer_running = 1;
}

static void buzzer_stop(void)
{
    TR0 = 0;
    ET0 = 0;
    BUZZER = 0;
    buzzer_running = 0;
}

/* Notes (half period us) */
#define NOTE_C4 1911U
#define NOTE_D4 1703U
#define NOTE_E4 1517U
#define NOTE_F4 1433U
#define NOTE_G4 1275U
#define NOTE_A4 1136U

/* ʱֵ����β������΢����һ��� */
#define DUR_SHORT    400U
#define DUR_LONG    1000U   /* ԭ 1200U -> 1000U */
#define NOTE_GAP_MS   30U   /* ������֮���� */
#define PHRASE_GAP_MS 90U   /* ��ĩ����ͣ�٣�120U -> 90U */

static const unsigned int code melody[] = {
    /* Phrase 1: C C G G A A G */
    NOTE_C4, NOTE_C4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_G4,
    /* Phrase 2: F F E E D D C */
    NOTE_F4, NOTE_F4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_D4, NOTE_C4,
    /* Phrase 3: G G F F E E D */
    NOTE_G4, NOTE_G4, NOTE_F4, NOTE_F4, NOTE_E4, NOTE_E4, NOTE_D4,
    /* Phrase 4: C C G G A A G */
    NOTE_C4, NOTE_C4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_G4,
    /* Phrase 5: F F E E D D C */
    NOTE_F4, NOTE_F4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_D4, NOTE_C4
};

static const unsigned int code durations[] = {
    /* Phrase 1 */
    DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_LONG,
    /* Phrase 2 */
    DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_LONG,
    /* Phrase 3 */
    DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_LONG,
    /* Phrase 4 */
    DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_LONG,
    /* Phrase 5 */
    DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_SHORT, DUR_LONG
};

#define MELODY_LEN (sizeof(melody) / sizeof(melody[0]))

/* ����״̬�� */
typedef enum {
    MUS_IDLE = 0,
    MUS_NOTE_ON,
    MUS_GAP
} mus_state_t;

static mus_state_t mus_state = MUS_IDLE;
static unsigned char mus_i = 0;
static unsigned long mus_deadline = 0; /* �����ʱ��㣨ms��ִ����һ�� */
static bit mus_screen_inited = 0;

static void music_reset(void)
{
    mus_state = MUS_IDLE;
    mus_i = 0;
    mus_deadline = 0;
    mus_screen_inited = 0;
    buzzer_stop();
}

/* ÿ����ѭ�����ã������� */
static void music_task(void)
{
    unsigned long now = millis();

    if (!mus_screen_inited) {
        LCD12864_Clear();
        LCD_ShowStr16x8(1, 0, (uint8_t *)"MUSC");
        LCD_ShowStr16x8(1, 32, (uint8_t *)"STAR");
        mus_screen_inited = 1;
    }

    switch (mus_state) {
    case MUS_IDLE:
        /* ��ʼ��һ�� */
        mus_i = 0;
        mus_state = MUS_NOTE_ON;
        /* fallthrough */

    case MUS_NOTE_ON:
        if (mus_i >= MELODY_LEN) {
            /* ������һ�飬ѭ������ */
            mus_i = 0;
        }
        /* ������ǰ�� */
        {
            unsigned int hp = pitch_half_period(melody[mus_i]);
            buzzer_set_half_period_us(hp);
            if (!buzzer_running) buzzer_start();
            mus_deadline = now + (unsigned long)durations[mus_i];
            mus_state = MUS_GAP; /* ��һ������ gap���ȹط��������ٵȼ���� */
        }
        break;

    case MUS_GAP:
        if (now >= mus_deadline) {
            /* ���㣺�ط������������á��������ʱ�䡱 */
            buzzer_stop();

            /* ����������ͨ�� gap + ��ĩ���� gap */
            {
                unsigned int gap = NOTE_GAP_MS;
                if (((mus_i + 1) % 7) == 0) gap += PHRASE_GAP_MS;
                mus_deadline = now + (unsigned long)gap;
            }

            /* ���롰�ȴ�����������׶Σ��� MUS_IDLE/MUS_NOTE_ON �������֣�
             * ���︴�� MUS_GAP������ buzzer_running=0 ��Ϊ���ѹط��������ı�� */
            mus_state = MUS_NOTE_ON;
            mus_i++; /* ��һ��������+1���ȼ�������ٴ�����һ�� */
            /* Ϊ���ü��Ҳ�ɼ�ʱ������� MUS_NOTE_ON �������ȴ���������������� */
            /* �� MUS_NOTE_ON ���ڻ���������������������һ��С���ɣ�deadline ��ʾ gap ������ */
            /* ��������һ�������жϣ��� now < deadline�������� */
        }
        break;

    default:
        mus_state = MUS_IDLE;
        break;
    }

    /* ���ȴ�������������������߼����� MUS_NOTE_ON �Ķ����Ӻ� */
    if (mus_state == MUS_NOTE_ON) {
        /* ��� deadline ����δ����˵������ gap �У���������һ�� */
        if (now < mus_deadline) {
            /* do nothing */
        } else {
            /* ���ڿ���������һ�������� MUS_NOTE_ON �������߼� */
            if (mus_i >= MELODY_LEN) mus_i = 0;
            {
                unsigned int hp2 = pitch_half_period(melody[mus_i]);
                buzzer_set_half_period_us(hp2);
                if (!buzzer_running) buzzer_start();
                mus_deadline = now + (unsigned long)durations[mus_i];
                /* �� MUS_GAP ���������ڷ������ȵ� deadline ��ط����������� gap�� */
                mus_state = MUS_GAP;
            }
        }
    }
}

/* ===================================================================== */
/* main                                                                   */
/* ===================================================================== */

void main()
{
    uint8_t prev_mode = 0;

    LCD12864_Init();
    systick_init();          /* <<<<<< 1ms tick ���� */
    music_reset();           /* ȷ����������ʼ�ر� */

    select_adc_channel(channel);
    CH_SEL = channel;

    while (1) {
        uint8_t i;
        uint8_t col, row, page;
        uint8_t Data, old_Data, old_page;
        uint8_t temp_Data2, temp_page;
        uint8_t t, d, k, tmp;

        uint8_t current_range_code;

        int maxv_mV, minv_mV, rmsv_mV;
        char numstr[6];
        uint8_t sample_value;
        int sample_mV;
        long sum_sq_mV;

        /* ===================== ������⣺����ʱ��Ķ̰� / �����ж� ===================== */
        if (KEY == 0) {
            /* �����ձ�����ʱ��¼ʱ�� */
            if (key_prev_state) {
                key_press_time_ms = millis();
                long_press_handled = 0;
            }
            /* ��ס�������ж��Ƿ�ﵽ����ʱ�� */
            if (!long_press_handled && (millis() - key_press_time_ms) >= KEY_LONG_PRESS_MS) {
                /* �����߼����ڷ�����ģʽ���л�����ͨ��������ģʽ�½��������� */
                if (mode != 3) {
                    channel ^= 1;
                    CH_SEL = !CH_SEL;
                    select_adc_channel(channel);
                    if (channel == 1) {
                        wave_index = 0;
                        current_range_code = ((uint8_t)RANGE1 << 1) | (uint8_t)RANGE0;
                        prev_range_code = current_range_code;
                        set_waveform_pins(wave_index);
                    }
                }
                LCD12864_Clear();
                if (mode == 3) {
                    music_reset();
                }
                long_press_handled = 1;
            }
            key_prev_state = 0;
        } else {
            /* �����ɿ����ж��Ƿ�Ϊ�̰� */
            if (!key_prev_state) {
                unsigned long press_duration = millis() - key_press_time_ms;
                if (!long_press_handled && press_duration < KEY_LONG_PRESS_MS) {
                    /* �̰�����ģʽ֮���л� */
                    if (mode == 1) mode = 2;
                    else if (mode == 2) mode = 3;
                    else mode = 1;
                    LCD12864_Clear();
                }
            }
            /* ��λ״̬ */
            key_prev_state = 1;
            long_press_handled = 0;
        }

        /* ģʽ�л�ʱ�Ľ��봦�� */
        if (mode != prev_mode) {
            if (prev_mode == 3) {
                /* �뿪����ģʽ������ֹͣ����������������״̬ */
                music_reset();
            }
            if (mode == 3) {
                /* ��������ģʽ�����ã���֤��ͷ���� */
                music_reset();
            }
            prev_mode = mode;
        }

        /* ===================== Mode handling ===================== */
        if (mode == 1) {
            /* Oscilloscope mode */
            old_Data = 0;
            old_page = 0;

            for (i = 0; i < COLLECT_NUM; i++) {
                sample_value = GatAdcValue();
                col = i;
                row = sample_value / 4;
                page = row / 8;
                Data = (uint8_t)(0x01 << (row - (page * 8)));

                refresh_one_list(col);

                if (i != 0) {
                    temp_Data2 = Data;
                    temp_page = page;

                    if (page == old_page) {
                        if (Data > old_Data) {
                            t = Data >> 1;
                            while (t != old_Data) {
                                t = t >> 1;
                                Data = (uint8_t)(Data | (Data >> 1));
                            }
                        } else if (Data < old_Data) {
                            t = Data << 1;
                            while (t != old_Data) {
                                t = t << 1;
                                Data = (uint8_t)(Data | (Data << 1));
                            }
                        }
                    } else if (page > old_page) {
                        t = Data;
                        for (k = 0; k < (row - (page * 8)); k++) t |= (t >> 1);
                        write_one_list(page, col, t);
                        page--;
                        while (page != old_page) {
                            write_one_list(page, col, 0xFF);
                            page--;
                        }
                        if (page == old_page) {
                            d = 0x80;
                            tmp = 0x80;
                            if (d > old_Data) {
                                tmp = tmp >> 1;
                                while (tmp != old_Data) {
                                    tmp = tmp >> 1;
                                    d = (uint8_t)(d | (d >> 1));
                                }
                            }
                            Data = d;
                            page = old_page;
                        }
                    } else { /* page < old_page */
                        t = Data;
                        for (k = 0; k < (7 - (row - (page * 8))); k++) t |= (t << 1);
                        write_one_list(page, col, t);
                        page++;
                        while (page != old_page) {
                            write_one_list(page, col, 0xFF);
                            page++;
                        }
                        if (page == old_page) {
                            d = 0x01;
                            tmp = 0x01;
                            if (d < old_Data) {
                                tmp = tmp << 1;
                                while (tmp != old_Data) {
                                    tmp = tmp << 1;
                                    d = (uint8_t)(d | (d << 1));
                                }
                            }
                            Data = d;
                            page = old_page;
                        }
                    }

                    old_Data = temp_Data2;
                    old_page = temp_page;
                } else {
                    old_Data = Data;
                    old_page = page;
                }

                write_one_list(page, col, Data);
            }

            if (channel == 0) LCD_ShowStr16x8(1, 96, (uint8_t *)"IN0");
            else              LCD_ShowStr16x8(1, 96, (uint8_t *)"IN1");

        } else if (mode == 2) {
            /* Voltmeter mode */
            maxv_mV = -32768;
            minv_mV =  32767;
            sum_sq_mV = 0;

            for (i = 0; i < COLLECT_NUM; i++) {
                sample_value = GatAdcValue();
                sample_mV = adc_to_mV(sample_value, channel);
                if (sample_mV > maxv_mV) maxv_mV = sample_mV;
                if (sample_mV < minv_mV) minv_mV = sample_mV;
                sum_sq_mV += (long)sample_mV * (long)sample_mV;
            }

            {
                unsigned long avg_sq = (unsigned long)sum_sq_mV / COLLECT_NUM;
                rmsv_mV = isqrt32ul(avg_sq);
            }

            LCD12864_Clear();

            if (channel == 1) {
                current_range_code = ((uint8_t)RANGE1 << 1) | (uint8_t)RANGE0;
                if (current_range_code != prev_range_code) {
                    wave_index = (uint8_t)((wave_index + 1) & 0x03);
                    set_waveform_pins(wave_index);
                    prev_range_code = current_range_code;
                }
            }

            if (channel == 0) {
                uint8_t range_code = ((uint8_t)RANGE1 << 1) | (uint8_t)RANGE0;
                LCD_ShowStr16x8(1, 0, (uint8_t *)"IN0 ");
                if      (range_code == 1) LCD_ShowStr16x8(1, 32, (uint8_t *)"2X");
                else if (range_code == 2) LCD_ShowStr16x8(1, 32, (uint8_t *)"4X");
                else                      LCD_ShowStr16x8(1, 32, (uint8_t *)"1X");
            } else {
                LCD_ShowStr16x8(1, 0, (uint8_t *)"IN1 ");
                switch (wave_index) {
                case 0: LCD_ShowStr16x8(1, 32, (uint8_t *)"SQRW"); break;
                case 1: LCD_ShowStr16x8(1, 32, (uint8_t *)"SAWT"); break;
                case 2: LCD_ShowStr16x8(1, 32, (uint8_t *)"TRIA"); break;
                default: LCD_ShowStr16x8(1, 32, (uint8_t *)"SINE"); break;
                }
            }

            LCD_ShowStr16x8(2, 0, (uint8_t *)"MAX:");
            voltage_to_str(maxv_mV, numstr);
            LCD_ShowStr16x8(2, 32, (uint8_t *)numstr);

            LCD_ShowStr16x8(3, 0, (uint8_t *)"MIN:");
            voltage_to_str(minv_mV, numstr);
            LCD_ShowStr16x8(3, 32, (uint8_t *)numstr);

            LCD_ShowStr16x8(4, 0, (uint8_t *)"RMS:");
            voltage_to_str(rmsv_mV, numstr);
            LCD_ShowStr16x8(4, 32, (uint8_t *)numstr);

        } else {
            /* Music mode - NON-BLOCKING */
            music_task();
        }
    }
}